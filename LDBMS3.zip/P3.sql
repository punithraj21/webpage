CREATE TABLE ACTOR(ACT_ID INTEGER PRIMARY KEY, ACT_NAME VARCHAR(30) NOT NULL, ACT_GENDER VARCHAR(10) NOT NULL);

CREATE TABLE DIRECTOR(DIR_ID INTEGER PRIMARY KEY, DIR_NAME VARCHAR(30) NOT NULL, DIR_PHONE INTEGER);

CREATE TABLE MOVIES(MOV_ID INTEGER PRIMARY KEY,MOV_TITLE VARCHAR(30) NOT NULL,MOV_YEAR INTEGER NOT NULL,MOV_LANG VARCHAR(10), DIR_ID INTEGER REFERENCES DIRECTOR(DIR_ID) ON DELETE CASCADE);

CREATE TABLE MOVIE_CASTE(ACT_ID INTEGER REFERENCES ACTOR(ACT_ID) ON DELETE CASCADE,MOV_ID INTEGER REFERENCES MOVIES(MOV_ID) ON DELETE CASCADE, ROLE VARCHAR(30) NOT NULL);

CREATE TABLE RATING(MOV_ID INTEGER REFERENCES MOVIES(MOV_ID) ON DELETE CASCADE, REV_STARS INTEGER NOT NULL);

INSERT INTO ACTOR VALUES(1001,'PRABHAS','MALE');
INSERT INTO ACTOR VALUES(1002,'RAJKUMAR','MALE');
INSERT INTO ACTOR VALUES(1003,'SNEHA','FEMALE');
INSERT INTO ACTOR VALUES(1004,'AISHWARAYA','FEMALE');
INSERT INTO ACTOR VALUES(1005,'RITHIK','MALE');

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
INSERT INTO DIRECTOR VALUES(2001,'HITCHCOCK','9639639630');
INSERT INTO DIRECTOR VALUES(2002,'STEVEN SPIELBERG','8887779991');
INSERT INTO DIRECTOR VALUES(2003,'RAJMOULI','9995556662');
INSERT INTO DIRECTOR VALUES(2004,'ATLEE','9874569874');
INSERT INTO DIRECTOR VALUES(2005,'HEMANTH','9874555780');


INSERT INTO MOVIES VALUES(3001,'BAHUBALI',2014,'HINDI',2003);
INSERT INTO MOVIES VALUES(3002,'BAHUBALI',2014,'TELUGU',2003);
INSERT INTO MOVIES VALUES(3003,'BAHUBALI 2',2016,'HINDI',2003);
INSERT INTO MOVIES VALUES(3004,'BAHUBALI 2',2016,'TELUGU',2003);
INSERT INTO MOVIES VALUES(3005,'BABY DRIVER ',1999,'ENGLISH',2001);
INSERT INTO MOVIES VALUES(3006,'TERMINATOR',2000,'ENGLISH',2002);


INSERT INTO MOVIE_CASTE VALUES(1001,3001,'HERO');
INSERT INTO MOVIE_CASTE VALUES(1001,3002,'HERO');
INSERT INTO MOVIE_CASTE VALUES(1001,3003,'HERO');
INSERT INTO MOVIE_CASTE VALUES(1001,3004,'HERO');
INSERT INTO MOVIE_CASTE VALUES(1003,3001,'HEROINE');
INSERT INTO MOVIE_CASTE VALUES(1003,3002,'HEROINE');
INSERT INTO MOVIE_CASTE VALUES(1004,3001,'HEROINE');
INSERT INTO MOVIE_CASTE VALUES(1004,3002,'HEROINE');
INSERT INTO MOVIE_CASTE VALUES(1001,3005,'HERO');
INSERT INTO MOVIE_CASTE VALUES(1001,3006,'HERO');


INSERT INTO RATING VALUES(3001,'8');
INSERT INTO RATING VALUES(3002,'7');
INSERT INTO RATING VALUES(3003,'6');
INSERT INTO RATING VALUES(3004,'7');
INSERT INTO RATING VALUES(3005,'4');
INSERT INTO RATING VALUES(3006,'2');

//QUERY 1
SELECT M.MOV_TITLE FROM MOVIES M,DIRECTOR D 
	WHERE D.DIR_NAME='HITCHCOCK' AND
		  D.DIR_ID=M.DIR_ID;

//QUERY 2
SELECT MOV_TITLE FROM MOVIES M,MOVIE_CASTE MC 
WHERE M.MOV_ID=MC.MOV_ID AND 
ACT_ID IN 
(SELECT ACT_ID FROM MOVIE_CASTE GROUP BY ACT_ID HAVING COUNT(ACT_ID)>1)
 GROUP BY MOV_TITLE HAVING COUNT(MOV_TITLE)>1;

//QUERY 3
SELECT ACT_NAME FROM ACTOR A,MOVIE_CASTE MC 
WHERE A.ACT_ID=MC.ACT_ID AND 
MC.MOV_ID IN 
(SELECT MOV_ID FROM MOVIES WHERE MOV_YEAR NOT BETWEEN 2000 AND 2015) 
GROUP BY ACT_NAME HAVING COUNT(*)>1;

//QUERY 4
SELECT MOV_TITLE,MAX(REV_STARS) FROM MOVIES M 
INNER JOIN RATING R ON M.MOV_ID=R.MOV_ID 
GROUP BY MOV_TITLE ORDER BY MOV_TITLE;

//QUERY 5
UPDATE RATING SET REV_STARS=5 WHERE MOV_ID IN 
(SELECT MOV_ID FROM MOVIES M,DIRECTOR D 
WHERE D.DIR_ID=M.DIR_ID AND DIR_NAME='STEVEN SPIELBERG');

SELECT * FROM RATING;